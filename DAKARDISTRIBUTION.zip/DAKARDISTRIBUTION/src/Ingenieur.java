
public class Ingenieur extends Employe{

	public int nombreHeureCom;
	
	public Ingenieur(String _prenom, String _nom, int _ID, int _heure_travail, float _taux_horaire) {
		super(_prenom, _nom, _ID, _heure_travail, _taux_horaire);
		this.nombreHeureCom = 0;
	}
	
	public int ajouterHeureCom(int extra){
		this.nombreHeureCom += extra ;
		return nombreHeureCom;
	}
}
