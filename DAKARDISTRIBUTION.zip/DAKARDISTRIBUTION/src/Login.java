import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JDesktopPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JSeparator;
import java.awt.Font;

public class Login extends JFrame {

	private JPanel contentPane;
	public static JTextField champ;
	public static JTextField champ0;
	public static JButton button1;

	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		
		JLabel label1 = new JLabel("Enter Username:");
		
		JLabel label2 = new JLabel("Enter Password:");
		
		champ = new JTextField();
		champ.setColumns(10);
		
		champ0 = new JPasswordField();
		champ0.setColumns(10);
		
		button1 = new JButton("Connexion");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String user = champ.getText();
					String pass = champ0.getText();
					mysql.preparedStatement = mysql.connect
						      .prepareStatement("select username,password from users where username = ? and password=?");
					
					mysql.preparedStatement.setString(1, user);
					mysql.preparedStatement.setString(2, pass);
					ResultSet result = mysql.preparedStatement.executeQuery();
					if(result.next()) {
						dispose();
						JOptionPane.showMessageDialog(button1, "You have successfully logged in");
						Accueil acc = new Accueil();
                        
                    }else {
                    	JOptionPane.showMessageDialog(button1, "Mauvais Username ou Password");
                    }
						
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		JSeparator separator = new JSeparator();
		
		JLabel lblNewLabel_2 = new JLabel("Connexion");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 14));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label1, GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
						.addComponent(label2, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(champ, GroupLayout.DEFAULT_SIZE, 301, Short.MAX_VALUE)
						.addComponent(champ0, GroupLayout.DEFAULT_SIZE, 301, Short.MAX_VALUE))
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(162)
					.addComponent(button1, GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
					.addGap(173))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
					.addGap(292))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(separator, GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 8, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(label1, GroupLayout.DEFAULT_SIZE, 14, Short.MAX_VALUE)
						.addComponent(champ))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(champ0, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(button1, GroupLayout.PREFERRED_SIZE, 14, Short.MAX_VALUE)
					.addGap(10))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
