
public class Manager extends Employe{

	public int nombreHeureGolfe;
	public Manager(String _prenom, String _nom, int _ID, int _heure_travail, float _taux_horaire) {
		super(_prenom, _nom, _ID, _heure_travail, _taux_horaire);
		this.nombreHeureGolfe = 0;
	}
	public int ajouterHeureGolfe(int extra) {
		this.nombreHeureGolfe += extra;
		return this.nombreHeureGolfe;
	}
}
