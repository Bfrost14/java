import java.sql.*;

public class mysql {
	  public static Connection connect = null;
	  public static Statement statement = null;
	  public static PreparedStatement preparedStatement = null;
	  public static ResultSet resultSet = null;

	  
	  public void readDataBase() throws Exception {
		    try {
		      // charger le driver
		      Class.forName("com.mysql.jdbc.Driver");
		      
		      // connection a la base de donn�e
		      connect = DriverManager.getConnection("jdbc:mysql://localhost/dakardistrub","root","");
		      
		    } catch (Exception e) {
		      throw e;
		    } 

		    
		  }

		}

