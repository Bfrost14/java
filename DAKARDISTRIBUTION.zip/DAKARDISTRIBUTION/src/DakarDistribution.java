import java.sql.*;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class DakarDistribution extends JFrame{

	public static void main(String[] args) {
		//mysql
		mysql sql = new mysql();
		try {
			sql.readDataBase();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			mysql.statement = mysql.connect.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//login
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login log = new Login();
					log.setTitle("Login");
					log.setVisible(true);
					log.setResizable(false);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
			
//		Manager mamadou = new Manager("Mamadou","Ndiaye",1,45,120);
//		Manager fatou = new Manager("Fatou","Diop",2,32,225);
//		
//		Ingenieur lamine = new Ingenieur("Lamine","Diop",3,70,220);
//		Ingenieur moussa = new Ingenieur("Moussa","Diop",4,42,220);
//		Ingenieur adama = new Ingenieur("Adama","Ndiaye",5,38,220);
//		Ingenieur mame = new Ingenieur("Mame","Ndiaye",6,44,220);
//		
//		Employe[] Employes= new Employe[6];
//		
//		Employes[0] = mamadou;
//		Employes[1] = fatou;
//		Employes[2] = lamine;
//		Employes[3] = moussa;
//		Employes[4] = adama;
//		Employes[5] = mame;
//		
//		float totale = 0;
//		for(int i =0 ; i< Employes.length; i++) {
//				 // requete prepar�
//			      try {
//					mysql.preparedStatement = mysql.connect
//					      .prepareStatement("insert into employe values (default, ?, ?, ?, ?,?)");
//					
//					  mysql.preparedStatement.setString(1, Employes[i].nom);
//				      mysql.preparedStatement.setString(2, Employes[i].prenom);
//				      mysql.preparedStatement.setInt(3, Employes[i].heure_travail);
//				      mysql.preparedStatement.setFloat(4, Employes[i].taux_horaire);
//				      mysql.preparedStatement.setString(5, Employes[i].getClass().getName());
//				      mysql.preparedStatement.executeUpdate();
//				} catch (SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}   
//  
//			totale += Employes[i].payHebdo();
//		}
//		
//		System.out.println(totale);
	}

}
