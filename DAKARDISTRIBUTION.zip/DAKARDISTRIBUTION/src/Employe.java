
public class Employe {
	public String prenom;
	public String nom;
	public int ID;
	public float salaire;
	public float taux_horaire;
	public int heure_travail;
	
	public Employe(String _prenom,String _nom,int _ID,int _heure_travail,float _taux_horaire) {
		this.prenom = _prenom;
		this.nom = _nom;
		this.ID = _ID;
		this.taux_horaire = _taux_horaire;
		this.heure_travail = _heure_travail;
		this.salaire = _taux_horaire * _heure_travail;
	}
	public float payHebdo() {
		if(this.salaire < 4500) {
			Accueil.erreur2.setText("Salaire de "+this.prenom+" "+this.nom+" inferieur au salaire de base");
		}
		if(this.heure_travail <= 40) {
			return this.salaire;
		}
		else if(this.heure_travail > 40 && this.heure_travail <= 60) {
			int i = this.heure_travail - 40;
			this.salaire *= (1.5* i); 
			return this.salaire;
		}
		else if(this.heure_travail > 60) {
			Accueil.erreur.setText("Salaire impossible pour l'employ� "+this.prenom+" "+this.nom+",");
		}
		return 0;
	}
	
}
