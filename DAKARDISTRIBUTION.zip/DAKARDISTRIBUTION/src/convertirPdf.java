import java.awt.EventQueue;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.BorderLayout;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter; 

public class convertirPdf {

	private JDialog conv;

	public convertirPdf() {
		initialisation();
	}

	private void initialisation() {
		conv = new JDialog();
		conv.setVisible(true);
		conv.setResizable(false);
		conv.setBounds(100, 100, 450, 300);
		conv.getContentPane().setLayout(null);
		
		JButton btn = new JButton("Convertir en Pdf");
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Document document = new Document(PageSize.A4);
				    try {
				      PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("DakarDistribution.pdf"));

				      document.open();
				      PdfContentByte cb = writer.getDirectContent();

				      cb.saveState();
				      Graphics2D g2 = cb.createGraphicsShapes(700, 805);

				      Shape oldClip = g2.getClip();
				     
				      g2.clipRect(0, 0, 700, 1280);

				     
				      Accueil.scrollPane.print(g2);
				      g2.setClip(oldClip); 

				      g2.dispose();
				      
				      cb.restoreState();
				      JOptionPane.showMessageDialog(null, "DakarDistribution.Pdf est Cr��", 
			                    "Information Message",
			                    JOptionPane.INFORMATION_MESSAGE);
				    } catch (Exception e3) {
				      System.err.println(e3.getMessage());
				    }
				    document.close();
				    
			}
		});
		btn.setBounds(140, 100, 170, 70);
		conv.getContentPane().add(btn);
	}
}
