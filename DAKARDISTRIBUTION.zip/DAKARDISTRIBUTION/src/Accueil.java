import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.*;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.DropMode;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import javax.swing.JSeparator;

import java.awt.FlowLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.DefaultComboBoxModel;

public class Accueil extends JFrame{

	private JFrame frame;
	private JTextField champ1;
	private JTextField champ2;
	private JTextField champ3;
	private JTextField textField;
	public static JScrollPane scrollPane;
	public static JTable table_2;
	public static JButton btn2;
	public static JLabel label7;
	private JTextField champbas;
	public static JTextField erreur;
	public static JTextField erreur2;
	public Accueil() {
		initialisation();
	}


	private void initialisation() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1280, 720);
		frame.setVisible(true);
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addWindowListener(new WindowAdapter() { //confirmation de fermeture du programme
			  public void windowClosing(WindowEvent e) {
			    int confirmation = JOptionPane.showConfirmDialog(null, 
			        "Etes vous sure de vouloir quitter le programme?", "Confirmation",
			        JOptionPane.YES_NO_OPTION);

			    if (confirmation == JOptionPane.YES_OPTION) {
			      dispose();
			    }
			  }
			});
		//creation de l'entetes et des nombres de lignes et de colonnes de la table
		String[][] data = new String[400][7];
		String entetes[] = {"Id","Nom","Prenom","Heure_travail","Taux_horaire","Type","Salaire" };
		

		JLabel lab1 = new JLabel("Formulaire d'ajout");
		lab1.setFont(new Font("Arial", Font.BOLD, 13));
		JLabel lab2 = new JLabel("Nom Emp:");
		lab2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		JLabel lab3 = new JLabel("Pr�noms:");
		JLabel lab4 = new JLabel("Heure travail:");
		JLabel lab5 = new JLabel("Type Emp:");
		JLabel label6 = new JLabel("Taux horaire:");
		label7 = new JLabel("Listes des Employes");
		label7.setFont(new Font("Tahoma", Font.PLAIN, 16));
		JLabel label8 = new JLabel("Montant totale des salaires est:");
		label8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		//champ du formulaire
		champ1 = new JTextField();
		champ1.setColumns(10);
		
		erreur = new JTextField();
		erreur.setColumns(10);
		
		erreur2 = new JTextField();
		erreur2.setColumns(10);
		
		champ2 = new JTextField();
		champ2.setColumns(10);
		
		champ3 = new JTextField();
		champ3.setColumns(10);
		
		textField = new JTextField();
		textField.setColumns(10);
		
		champbas = new JTextField();
		champbas.setEnabled(true);
		champbas.setColumns(10); 
		
		JComboBox deroulante = new JComboBox();
		deroulante.setModel(new DefaultComboBoxModel(new String[] {"Manager", "Ingenieur"}));
		
		//Barre de menu
				JMenuBar menuBar = new JMenuBar();
				frame.setJMenuBar(menuBar);
				
				JMenu menu1 = new JMenu("Fichier");
				menuBar.add(menu1);
				
				//sous barre de menu
				JMenuItem sousMenu2 = new JMenuItem("Convert en pdf");
				sousMenu2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(e.getSource() == sousMenu2) {
							convertirPdf conv = new convertirPdf();
						}	
					}
				});
				menu1.add(sousMenu2);
				
				JMenu menu2 = new JMenu("Quitter");
				menu2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(e.getSource()==menu2) {
							addWindowListener(new WindowAdapter() {
								  public void windowClosing(WindowEvent e) {
								    int confirmation = JOptionPane.showConfirmDialog(null, 
								        "Etes vous sure de vouloir quitter le programme?", "Confirmation",
								        JOptionPane.YES_NO_OPTION);

								    if (confirmation == JOptionPane.YES_OPTION) {
								      dispose();
								    }
								  }
								});
						}
						
					}
				});
				menuBar.add(menu2);
				
				JSeparator separator = new JSeparator();
				separator.setOrientation(SwingConstants.VERTICAL);
				
				
				//creation table
				table_2 = new JTable(data,entetes);
				table_2.getModel().addTableModelListener(new TableModelListener() {
					//modification des donn�es de la table
					@Override
					public void tableChanged(TableModelEvent e) {
						if(e.getType()==(TableModelEvent.UPDATE)) {
							int intColumn = e.getColumn();
							int intRows = e.getFirstRow();
							UpdateData(intRows,intColumn);
						}	
					}
					
				}); 
				scrollPane = new JScrollPane(table_2);
		
		//connexion a mysql
		try {
			mysql req = new mysql();
			try {
				req.readDataBase();
				
				mysql.statement = mysql.connect.createStatement();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//recuperation des donnees
			mysql.preparedStatement = mysql.connect
				      .prepareStatement("select * from employe");
			

			ResultSet result = mysql.preparedStatement.executeQuery();
			int i = 0;
			Employe[] Employes= new Employe[100];
		    Employe mon;
			while(result.next()) {
			data[i][0]= result.getString("id");
			data[i][1]= result.getString("nom");
			data[i][2]= result.getString("prenom");
			data[i][3]= result.getString("heure_travail");
			data[i][4]= result.getString("taux_horaire");
			data[i][5]= result.getString("type");
			float enc;
			mon = new Employe(data[i][2],data[i][1],Integer.parseInt(data[i][0]),Integer.parseInt(data[i][3]),Float.parseFloat(data[i][4]));
	        Employes[i] = mon;
			enc = Employes[i].payHebdo();
			data[i][6]= enc+"";
			i++;
			}
		} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
		
		
		
		//Enregistrement des donn�es
		JButton btn = new JButton("Enregistrer");
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					mysql.preparedStatement = mysql.connect
					      .prepareStatement("insert into employe values (default, ?, ?, ?, ?,?)");
					
					  mysql.preparedStatement.setString(1, champ1.getText());
				      mysql.preparedStatement.setString(2, champ2.getText());
				      mysql.preparedStatement.setString(3, champ3.getText());
				      mysql.preparedStatement.setString(4, textField.getText());
				      mysql.preparedStatement.setString(5, deroulante.getSelectedItem().toString());
				      if(mysql.preparedStatement.executeUpdate() == 1) {
				    	  JOptionPane.showMessageDialog(null, "Success", 
				                    "Information Message",
				                    JOptionPane.INFORMATION_MESSAGE);
				    	  champ3.setText(" ");
					      champ2.setText(" ");
					      champ1.setText(" ");
					      textField.setText(" ");
					      
					      try {
								mysql.preparedStatement = mysql.connect
									      .prepareStatement("select * from employe");
								

								ResultSet result = mysql.preparedStatement.executeQuery();
								int i = 0;
								Employe[] Employes= new Employe[100];
							    Employe mon;
								while(result.next()) {
								data[i][0]= result.getString("id");
								data[i][1]= result.getString("nom");
								data[i][2]= result.getString("prenom");
								data[i][3]= result.getString("heure_travail");
								data[i][4]= result.getString("taux_horaire");
								data[i][5]= result.getString("type");
								float enc;
								mon = new Employe(data[i][2],data[i][1],Integer.parseInt(data[i][0]),Integer.parseInt(data[i][3]),Float.parseFloat(data[i][4]));
						        Employes[i] = mon;
								enc = Employes[i].payHebdo();
								data[i][6]= enc+"";
								i++;
								}
							} catch (SQLException e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							} 
				      }     					      
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}   
			}
		});
		
		
		
		
		btn2 = new JButton("Salaire Totale");
		//Montrer le totaledes salaires
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float totale = 0;
				try {
					mysql.preparedStatement = mysql.connect
						      .prepareStatement("select * from employe");
					ResultSet resultats = mysql.preparedStatement.executeQuery();
					ResultSetMetaData rsmd = resultats.getMetaData();
					int nbCols = rsmd.getColumnCount();
				     Employe[] Employes= new Employe[100];
				     Employe mon;
				     while(resultats.next()) {
				    	 for(int i= 0; i < 1; i++) {
					    	 String nom = resultats.getString("nom");
					         String prenom = resultats.getString("prenom");
					         int id = resultats.getInt("id");
					         int heure_travail = resultats.getInt("heure_travail");
					         Float taux = resultats.getFloat("taux_horaire");
					         
					         mon = new Employe(prenom,nom,id,heure_travail,taux);
					         Employes[i] = mon;
					         totale += Employes[i].payHebdo();
						     }
				     }
				     champbas.setText(totale+"");
				     
				} catch (SQLException e2) {
					e2.printStackTrace();
				}

			}
		});
		
		
		
		
		//Frame GroupLayout
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(89)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lab5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lab4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(label6, Alignment.LEADING))
									.addGap(18)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(textField, GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)
										.addComponent(deroulante, 0, 278, Short.MAX_VALUE)
										.addComponent(champ3, GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)))
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(lab3)
										.addComponent(lab2))
									.addGap(39)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
										.addComponent(champ2, GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
										.addComponent(champ1, GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE))))
							.addGap(74))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(231)
							.addComponent(lab1, GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
							.addGap(133))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(211)
							.addComponent(btn, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
							.addGap(150)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, 8, GroupLayout.PREFERRED_SIZE)
					.addGap(68)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label8, GroupLayout.PREFERRED_SIZE, 244, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(champbas, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
							.addGap(159))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label7, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 369, Short.MAX_VALUE)
									.addComponent(btn2))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(erreur, GroupLayout.PREFERRED_SIZE, 312, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(erreur2, GroupLayout.PREFERRED_SIZE, 290, GroupLayout.PREFERRED_SIZE)))
							.addGap(43))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(51)
					.addComponent(lab1, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(champ1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lab2))
					.addGap(38)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lab3)
						.addComponent(champ2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(34)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(lab4)
						.addComponent(champ3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(39)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(deroulante, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lab5))
					.addGap(34)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label6)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addComponent(btn, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(label7, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
						.addComponent(btn2))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 493, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(erreur, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addComponent(erreur2, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label8, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
						.addComponent(champbas, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(30, Short.MAX_VALUE))
				.addComponent(separator, GroupLayout.DEFAULT_SIZE, 659, Short.MAX_VALUE)
		);
		frame.getContentPane().setLayout(groupLayout);
		
		
		
	}
	//mise a jour du tableau
			private void UpdateData(int Rows,int Column) {
				try {
					mysql req = new mysql();
					try {
						req.readDataBase();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					mysql.statement = mysql.connect.createStatement();
					
					String id = table_2.getValueAt(Rows, 0).toString();
					String nom = table_2.getValueAt(Rows, 1).toString();
					String prenom = table_2.getValueAt(Rows, 2).toString();
					String heure = table_2.getValueAt(Rows, 3).toString();
					String taux = table_2.getValueAt(Rows, 4).toString();
					
					mysql.preparedStatement = mysql.connect
						      .prepareStatement("UPDATE employe SET nom= '"
						      		+ nom + "'"+", prenom='"
						      				+ prenom+"'"+", heure_travail='"
						      						+ heure +"'"+", taux_horaire='"
						      								+ taux +"'"+" WHERE id = "+id);
					mysql.preparedStatement.execute();
				} catch (SQLException e7) {
					e7.printStackTrace();
				}
				
			}
}
