-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 31 juil. 2021 à 19:12
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `dakardistrub`
--

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(255) COLLATE utf8_bin NOT NULL,
  `heure_travail` int(11) NOT NULL,
  `taux_horaire` float NOT NULL,
  `type` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `employe`
--

INSERT INTO `employe` (`id`, `nom`, `prenom`, `heure_travail`, `taux_horaire`, `type`) VALUES
(334, 'Ndiaye', 'Mamadou', 45, 120, 'Manager'),
(335, 'Diop', 'Fatou', 32, 225, 'Manager'),
(336, 'Diop', 'Lamine', 70, 220, 'Ingenieur'),
(337, 'Diop', 'Moussa', 42, 220, 'Ingenieur'),
(338, 'Ndiaye', 'Adama', 38, 220, 'Ingenieur'),
(339, 'Ndiaye', 'Mame', 44, 220, 'Ingenieur'),
(344, 'Dieng', 'Mamadou', 56, 500, 'Manager'),
(345, 'Dieng', 'Bachir', 55, 500, 'Manager'),
(346, 'Diagne', 'Pape', 45, 450, 'Ingenieur'),
(347, 'Diagne', 'Pape', 45, 450, 'Ingenieur'),
(348, 'Dieng', 'papa', 27, 111, 'Ingenieur'),
(349, 'Diop', ' Modou', 60, 900, 'Manager'),
(350, 'Monsieur', 'Mbaye', 40, 10000, 'Manager'),
(351, 'Monsieur', 'Mbaye', 40, 10000, 'Manager'),
(352, 'Kane', 'moussa', 45, 899, 'Manager'),
(353, 'Bishri', 'Mouhamed', 35, 900, 'Ingenieur'),
(354, 'Faye', 'bachir', 45, 1000, 'Ingenieur'),
(355, 'Diakhte', 'jujutsu', 23, 1000, 'Manager'),
(356, 'Ba', 'Aicha', 39, 43, 'Ingenieur'),
(357, 'Dieng', 'Mouhamed', 35, 700, 'Manager');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('bfrost', 'sate');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
